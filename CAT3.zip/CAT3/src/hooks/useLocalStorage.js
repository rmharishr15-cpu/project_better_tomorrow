import { useState, useEffect } from 'react';

/**
 * useLocalStorage — thin wrapper around useState that persists to localStorage.
 * Handles JSON parse errors gracefully.
 */
export function useLocalStorage(key, defaultValue) {
  const [value, setValue] = useState(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw === null) return defaultValue;
      return JSON.parse(raw);
    } catch {
      return defaultValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // storage quota exceeded or private mode – silently ignore
    }
  }, [key, value]);

  return [value, setValue];
}
