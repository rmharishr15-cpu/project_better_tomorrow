import { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Empathize from './pages/Empathize';
import Define from './pages/Define';
import Ideate from './pages/Ideate';
import Prototype from './pages/Prototype';
import Validate from './pages/Validate';
import Report from './pages/Report';

export const PAGES = {
  dashboard: 'dashboard',
  empathize: 'empathize',
  define: 'define',
  ideate: 'ideate',
  prototype: 'prototype',
  validate: 'validate',
  report: 'report',
};

export default function App() {
  const [page, setPage] = useState(PAGES.dashboard);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navigate = (p) => {
    setPage(p);
    setSidebarOpen(false);
    window.scrollTo(0, 0);
  };

  const pageComponents = {
    [PAGES.dashboard]: <Dashboard navigate={navigate} />,
    [PAGES.empathize]: <Empathize />,
    [PAGES.define]: <Define />,
    [PAGES.ideate]: <Ideate />,
    [PAGES.prototype]: <Prototype />,
    [PAGES.validate]: <Validate />,
    [PAGES.report]: <Report navigate={navigate} />,
  };

  return (
    <div className="app-layout">
      {/* Mobile header */}
      <header className="mobile-header">
        <button
          className="icon-btn"
          aria-label="Open navigation"
          onClick={() => setSidebarOpen(true)}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="3" y1="6" x2="21" y2="6"/>
            <line x1="3" y1="12" x2="21" y2="12"/>
            <line x1="3" y1="18" x2="21" y2="18"/>
          </svg>
        </button>
        <span className="logo-text">Better Tomorrow</span>
        <div style={{width:28}} />
      </header>

      {/* Overlay */}
      <div
        className={`overlay ${sidebarOpen ? 'visible' : ''}`}
        onClick={() => setSidebarOpen(false)}
      />

      <Sidebar
        currentPage={page}
        navigate={navigate}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="main-content">
        <div className="page-wrapper">
          {pageComponents[page]}
        </div>
      </main>
    </div>
  );
}
