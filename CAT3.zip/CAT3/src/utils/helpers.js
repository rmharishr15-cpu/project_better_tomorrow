/** Generate a simple unique ID */
export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/** Format a date string to readable format */
export function fmtDate(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
    });
  } catch {
    return iso;
  }
}

/** Check if a date string represents a past date */
export function isOverdue(dateStr) {
  if (!dateStr) return false;
  return new Date(dateStr) < new Date(new Date().toDateString());
}

/** Truncate text to maxLen characters */
export function truncate(text = '', maxLen = 80) {
  return text.length > maxLen ? text.slice(0, maxLen) + '…' : text;
}

/** Priority metadata */
export const PRIORITIES = {
  high:   { label: 'High',   className: 'priority-high' },
  medium: { label: 'Medium', className: 'priority-medium' },
  low:    { label: 'Low',    className: 'priority-low' },
};

/** Subjects list for prototype */
export const SUBJECTS = [
  'Mathematics', 'Physics', 'Chemistry', 'Computer Science',
  'English', 'History', 'Economics', 'Biology', 'Other',
];
