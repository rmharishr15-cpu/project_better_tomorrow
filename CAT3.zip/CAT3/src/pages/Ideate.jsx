import { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { uid } from '../utils/helpers';

/* -------------------------------------------------------
   DEMO IDEAS — clearly labelled, deterministic, local.
   No AI API is called. This is a demo/illustration mode.
------------------------------------------------------- */
const DEMO_IDEAS = [
  {
    id: 'demo-1', _demo: true,
    title: 'Unified Deadline Dashboard',
    explanation: 'A single-screen view aggregating all assignment deadlines from all subjects, colour-coded by urgency and subject.',
    benefit: 'Students see everything in one glance without switching between apps.',
    feasibility: 'High',
    risks: 'Integration with different institution LMS platforms may vary.',
    assumptions: 'Students check a single app daily; data entry is manual initially.',
    decision: 'adopt', decisionReason: '',
  },
  {
    id: 'demo-2', _demo: true,
    title: 'Smart Reminder Escalation',
    explanation: 'Adaptive reminders that increase in frequency as a deadline approaches (7 days → 3 days → 1 day → morning of).',
    benefit: 'Reduces last-minute surprises without creating notification fatigue.',
    feasibility: 'Medium',
    risks: 'Users may disable notifications if poorly tuned.',
    assumptions: 'Device notifications are permitted; users do not turn off the app.',
    decision: null, decisionReason: '',
  },
  {
    id: 'demo-3', _demo: true,
    title: 'Subject Colour Tagging',
    explanation: 'Each subject is assigned a user-chosen colour. All tasks and deadline indicators for that subject use the same colour throughout the UI.',
    benefit: 'Instant visual recognition reduces cognitive load when scanning task lists.',
    feasibility: 'High',
    risks: 'Colour-blind accessibility must be addressed alongside colour tags.',
    assumptions: 'Users will configure colours once during onboarding.',
    decision: 'adopt', decisionReason: '',
  },
  {
    id: 'demo-4', _demo: true,
    title: 'Weekly Focus Mode',
    explanation: 'A condensed weekly view showing only tasks due in the next 7 days, hiding long-future items to reduce overwhelm.',
    benefit: 'Reduces cognitive overload by surfacing only what is immediately relevant.',
    feasibility: 'High',
    risks: 'Users may miss tasks just outside the 7-day window.',
    assumptions: 'Users review the tool at least once a week.',
    decision: null, decisionReason: '',
  },
];

const FEASIBILITY_OPTIONS = ['High', 'Medium', 'Low'];
const DECISION_OPTIONS = [
  { value: '', label: 'Undecided' },
  { value: 'adopt', label: '✓ Adopt' },
  { value: 'revise', label: '✏ Revise' },
  { value: 'reject', label: '✗ Reject' },
];

const BLANK_AUDIT = {
  prompt: '', aiOutput: '', adoptedElements: '', rejectedElements: '', corrections: '', date: '',
};

function IdeaCard({ idea, onUpdate, onDelete }) {
  const [expanded, setExpanded] = useState(false);

  const decisionColor = {
    adopt: 'var(--success)',
    revise: 'var(--warning)',
    reject: 'var(--danger)',
  }[idea.decision] || 'var(--text-muted)';

  return (
    <div className={`idea-card ${idea.decision || ''}`} style={{ opacity: idea.decision === 'reject' ? 0.55 : 1 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:10 }}>
        <div style={{ flex:1 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap', marginBottom:4 }}>
            <span style={{ fontWeight:700, fontSize:'0.95rem', color:'var(--text-primary)' }}>{idea.title}</span>
            {idea._demo && <span className="badge badge-sample">⚠ DEMO IDEA — NOT AI GENERATED</span>}
            {idea.decision && (
              <span style={{ fontSize:'0.75rem', fontWeight:700, color: decisionColor }}>
                {DECISION_OPTIONS.find(d => d.value === idea.decision)?.label}
              </span>
            )}
          </div>
          <p style={{ fontSize:'0.85rem', color:'var(--text-secondary)', lineHeight:1.5 }}>{idea.explanation}</p>
        </div>
        <button className="icon-btn" onClick={() => setExpanded(e => !e)} aria-label={expanded ? 'Collapse' : 'Expand'}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {expanded
              ? <polyline points="18 15 12 9 6 15"/>
              : <polyline points="6 9 12 15 18 9"/>
            }
          </svg>
        </button>
      </div>

      {expanded && (
        <div style={{ marginTop:14 }}>
          <div className="divider" style={{ margin:'8px 0 12px' }} />
          <div className="form-grid form-grid-2" style={{ marginBottom:12 }}>
            {[
              { label:'User Benefit', val: idea.benefit, field:'benefit' },
              { label:'Feasibility', val: idea.feasibility, field:'feasibility', type:'select' },
              { label:'Risks', val: idea.risks, field:'risks' },
              { label:'Assumptions', val: idea.assumptions, field:'assumptions' },
            ].map(({ label, val, field, type }) => (
              <div key={field}>
                <div style={{ fontSize:'0.72rem', fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:4 }}>
                  {label}
                </div>
                {type === 'select' ? (
                  <select
                    className="form-select"
                    value={val}
                    onChange={e => onUpdate(idea.id, field, e.target.value)}
                  >
                    {FEASIBILITY_OPTIONS.map(f => <option key={f}>{f}</option>)}
                  </select>
                ) : (
                  <textarea
                    className="form-textarea"
                    style={{ minHeight:55, fontSize:'0.8rem' }}
                    value={val}
                    onChange={e => onUpdate(idea.id, field, e.target.value)}
                  />
                )}
              </div>
            ))}
          </div>

          <div className="form-grid form-grid-2">
            <div>
              <div style={{ fontSize:'0.72rem', fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:4 }}>
                Decision
              </div>
              <select
                className="form-select"
                value={idea.decision || ''}
                onChange={e => onUpdate(idea.id, 'decision', e.target.value)}
              >
                {DECISION_OPTIONS.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
              </select>
            </div>
            <div>
              <div style={{ fontSize:'0.72rem', fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:4 }}>
                Reason for Decision
              </div>
              <textarea
                className="form-textarea"
                style={{ minHeight:60, fontSize:'0.8rem' }}
                placeholder="Why did you adopt, revise, or reject this idea?"
                value={idea.decisionReason || ''}
                onChange={e => onUpdate(idea.id, 'decisionReason', e.target.value)}
              />
            </div>
          </div>

          {!idea._demo && (
            <button className="btn btn-danger btn-sm" style={{ marginTop:10 }} onClick={() => onDelete(idea.id)}>
              Delete idea
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export default function Ideate() {
  const [tab, setTab] = useState('ideas');
  const [ideas, setIdeas] = useLocalStorage('bt_ideas', []);
  const [auditLog, setAuditLog] = useLocalStorage('bt_ai_audit', []);
  const [problemInput, setProblemInput] = useState('');
  const [showDemo, setShowDemo] = useState(false);
  const [auditForm, setAuditForm] = useState({ ...BLANK_AUDIT });
  const [newIdea, setNewIdea] = useState({ title:'', explanation:'', benefit:'', feasibility:'High', risks:'', assumptions:'' });
  const [newIdeaErrors, setNewIdeaErrors] = useState({});

  const [problemStatement] = useLocalStorage('bt_problem_statement', {});
  const autoStatement = problemStatement.userGroup
    ? `${problemStatement.userGroup} needs a way to ${problemStatement.userNeed} because ${problemStatement.insight}.`
    : '';

  const allIdeas = showDemo ? [...DEMO_IDEAS, ...ideas] : ideas;

  function updateIdea(id, field, val) {
    // update in real ideas
    setIdeas(prev => prev.map(i => i.id === id ? { ...i, [field]: val } : i));
    // demo ideas are read-only in storage but we can update local display via showDemo
  }

  function deleteIdea(id) {
    setIdeas(prev => prev.filter(i => i.id !== id));
  }

  function addIdea(e) {
    e.preventDefault();
    const errs = {};
    if (!newIdea.title.trim()) errs.title = 'Title is required.';
    if (!newIdea.explanation.trim()) errs.explanation = 'Explanation is required.';
    if (Object.keys(errs).length) { setNewIdeaErrors(errs); return; }
    setIdeas(prev => [{ ...newIdea, id: uid(), decision: null, decisionReason:'' }, ...prev]);
    setNewIdea({ title:'', explanation:'', benefit:'', feasibility:'High', risks:'', assumptions:'' });
    setNewIdeaErrors({});
  }

  function saveAudit(e) {
    e.preventDefault();
    if (!auditForm.prompt.trim()) return;
    setAuditLog(prev => [{ ...auditForm, id: uid() }, ...prev]);
    setAuditForm({ ...BLANK_AUDIT });
  }

  function deleteAudit(id) {
    setAuditLog(prev => prev.filter(a => a.id !== id));
  }

  return (
    <div>
      <div style={{ marginBottom:24 }}>
        <h1 className="page-title">💡 Ideate</h1>
        <p className="page-subtitle">Generate, evaluate, and decide on solution ideas using a transparent process.</p>
      </div>

      <div className="alert alert-info" style={{ marginBottom:16 }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
          <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="8"/><line x1="12" y1="12" x2="12" y2="16"/>
        </svg>
        <span>
          <strong>Demo mode:</strong> No AI API is connected. Enable &ldquo;Show demo ideas&rdquo; to see example ideas clearly
          labelled as illustrative. Add your own real ideas using the form below. A real AI provider
          can be integrated later through a secure backend.
        </span>
      </div>

      <div className="tab-nav">
        {[
          { id:'ideas', label:'💡 Ideas' },
          { id:'add', label:'➕ Add Idea' },
          { id:'audit', label:'📋 AI Audit Log' },
        ].map(t => (
          <button key={t.id} className={`tab-btn ${tab===t.id?'active':''}`} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Ideas list */}
      {tab === 'ideas' && (
        <div>
          {/* Problem input */}
          <div className="card" style={{ marginBottom:16 }}>
            <div className="form-group" style={{ marginBottom:0 }}>
              <label className="label" htmlFor="prob-in">Problem Statement (used for ideation context)</label>
              <textarea
                id="prob-in"
                className="form-textarea"
                style={{ minHeight:65 }}
                placeholder='Paste your problem statement here, e.g. "Students need a way to…"'
                value={problemInput || autoStatement}
                onChange={e => setProblemInput(e.target.value)}
              />
            </div>
            {autoStatement && !problemInput && (
              <div className="form-hint" style={{ marginTop:6 }}>
                ↑ Auto-filled from your Define stage. Edit if needed.
              </div>
            )}
          </div>

          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <h2 className="section-title" style={{ marginBottom:0 }}>
              Solution Ideas ({ideas.length} real + {showDemo ? DEMO_IDEAS.length : 0} demo)
            </h2>
            <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer', fontSize:'0.8rem', color:'var(--text-secondary)' }}>
              <input type="checkbox" checked={showDemo} onChange={e => setShowDemo(e.target.checked)} />
              Show demo ideas
            </label>
          </div>

          {allIdeas.length === 0 ? (
            <div className="empty-state card">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              <h3>No ideas yet</h3>
              <p>Use the &ldquo;Add Idea&rdquo; tab to record ideas, or enable demo ideas above.</p>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
              {allIdeas.map(idea => (
                <IdeaCard
                  key={idea.id}
                  idea={idea}
                  onUpdate={updateIdea}
                  onDelete={deleteIdea}
                />
              ))}
            </div>
          )}

          {/* Decision summary */}
          {allIdeas.length > 0 && (
            <div className="card" style={{ marginTop:20 }}>
              <h3 className="section-title">Decision Summary</h3>
              <div style={{ display:'flex', gap:20, flexWrap:'wrap' }}>
                {[
                  { label:'Adopted', val:'adopt', color:'var(--success)' },
                  { label:'To Revise', val:'revise', color:'var(--warning)' },
                  { label:'Rejected', val:'reject', color:'var(--danger)' },
                  { label:'Undecided', val:'', color:'var(--text-muted)' },
                ].map(d => (
                  <div key={d.val || 'none'} style={{ textAlign:'center' }}>
                    <div style={{ fontSize:'1.8rem', fontWeight:800, color: d.color }}>
                      {allIdeas.filter(i => (i.decision || '') === d.val).length}
                    </div>
                    <div style={{ fontSize:'0.72rem', color:'var(--text-muted)', textTransform:'uppercase' }}>{d.label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Add idea */}
      {tab === 'add' && (
        <div className="card">
          <h2 className="section-title">Add a New Idea</h2>
          <form onSubmit={addIdea} noValidate>
            <div className="form-group">
              <label className="label" htmlFor="idtitle">Idea Title *</label>
              <input
                id="idtitle"
                className="form-input"
                placeholder="Short descriptive title"
                value={newIdea.title}
                onChange={e => setNewIdea(n => ({ ...n, title: e.target.value }))}
              />
              {newIdeaErrors.title && <div className="form-error">{newIdeaErrors.title}</div>}
            </div>
            <div className="form-group">
              <label className="label" htmlFor="idexpl">Explanation *</label>
              <textarea
                id="idexpl"
                className="form-textarea"
                placeholder="How does this idea work?"
                value={newIdea.explanation}
                onChange={e => setNewIdea(n => ({ ...n, explanation: e.target.value }))}
              />
              {newIdeaErrors.explanation && <div className="form-error">{newIdeaErrors.explanation}</div>}
            </div>
            <div className="form-grid form-grid-2">
              <div className="form-group">
                <label className="label" htmlFor="idbenefit">User Benefit</label>
                <textarea id="idbenefit" className="form-textarea" style={{ minHeight:65 }}
                  placeholder="What problem does it solve for the user?"
                  value={newIdea.benefit}
                  onChange={e => setNewIdea(n => ({ ...n, benefit: e.target.value }))} />
              </div>
              <div className="form-group">
                <label className="label" htmlFor="idfeas">Feasibility</label>
                <select id="idfeas" className="form-select"
                  value={newIdea.feasibility}
                  onChange={e => setNewIdea(n => ({ ...n, feasibility: e.target.value }))}>
                  {FEASIBILITY_OPTIONS.map(f => <option key={f}>{f}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="label" htmlFor="idrisks">Risks</label>
                <textarea id="idrisks" className="form-textarea" style={{ minHeight:65 }}
                  placeholder="What could go wrong?"
                  value={newIdea.risks}
                  onChange={e => setNewIdea(n => ({ ...n, risks: e.target.value }))} />
              </div>
              <div className="form-group">
                <label className="label" htmlFor="idassump">Assumptions</label>
                <textarea id="idassump" className="form-textarea" style={{ minHeight:65 }}
                  placeholder="What are you assuming to be true?"
                  value={newIdea.assumptions}
                  onChange={e => setNewIdea(n => ({ ...n, assumptions: e.target.value }))} />
              </div>
            </div>
            <button type="submit" className="btn btn-primary">Save Idea</button>
          </form>
        </div>
      )}

      {/* AI Audit */}
      {tab === 'audit' && (
        <div>
          <div className="alert alert-orange" style={{ marginBottom:16 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
            </svg>
            <span>
              Record every interaction where AI tools were used. Include the prompt, output, what you adopted,
              what you rejected, and any factual corrections. This creates your AI audit trail.
            </span>
          </div>

          <div className="card" style={{ marginBottom:18 }}>
            <h2 className="section-title">Log AI Interaction</h2>
            <form onSubmit={saveAudit} noValidate>
              <div className="form-grid form-grid-2">
                <div className="form-group">
                  <label className="label" htmlFor="adate">Date</label>
                  <input id="adate" type="date" className="form-input"
                    value={auditForm.date}
                    onChange={e => setAuditForm(f => ({ ...f, date: e.target.value }))} />
                </div>
              </div>
              {[
                { id:'aprompt', field:'prompt', label:'Prompt Given to AI *', ph:'What prompt/question did you give the AI tool?' },
                { id:'aoutput', field:'aiOutput', label:'AI Output', ph:'Paste or summarise what the AI returned.' },
                { id:'aadopt', field:'adoptedElements', label:'Adopted Elements', ph:'Which parts of the AI output did you use?' },
                { id:'areject', field:'rejectedElements', label:'Rejected Elements', ph:'Which parts did you discard and why?' },
                { id:'acorr', field:'corrections', label:'Factual Corrections', ph:'Did you correct any AI errors? List them.' },
              ].map(row => (
                <div key={row.id} className="form-group">
                  <label className="label" htmlFor={row.id}>{row.label}</label>
                  <textarea
                    id={row.id}
                    className="form-textarea"
                    placeholder={row.ph}
                    value={auditForm[row.field]}
                    onChange={e => setAuditForm(f => ({ ...f, [row.field]: e.target.value }))}
                    style={{ minHeight:70 }}
                  />
                </div>
              ))}
              <button type="submit" className="btn btn-primary">Save Audit Record</button>
            </form>
          </div>

          {auditLog.length === 0 ? (
            <div className="empty-state card">
              <h3>No AI interactions logged</h3>
              <p>Every time you use an AI tool (ChatGPT, Gemini, etc.) record it here.</p>
            </div>
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Prompt (preview)</th>
                    <th>Adopted</th>
                    <th>Rejected</th>
                    <th>Corrections</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {auditLog.map(a => (
                    <tr key={a.id}>
                      <td style={{ whiteSpace:'nowrap' }}>{a.date || '—'}</td>
                      <td style={{ maxWidth:200 }}>{a.prompt?.slice(0,60)}…</td>
                      <td>{a.adoptedElements?.slice(0,40) || '—'}</td>
                      <td>{a.rejectedElements?.slice(0,40) || '—'}</td>
                      <td>{a.corrections?.slice(0,40) || '—'}</td>
                      <td><button className="btn btn-danger btn-sm" onClick={() => deleteAudit(a.id)}>Del</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
