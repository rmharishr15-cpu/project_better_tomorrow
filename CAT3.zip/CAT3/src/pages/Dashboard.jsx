import { useLocalStorage } from '../hooks/useLocalStorage';

const STAGES = [
  {
    id: 'empathize',
    name: 'Empathize',
    className: 'empathize',
    desc: 'Interview users, log observations, map pain points.',
    icon: '💜',
    color: 'var(--purple)',
    status: 'wip',
  },
  {
    id: 'define',
    name: 'Define',
    className: 'define',
    desc: 'Synthesise insights into a clear problem statement.',
    icon: '🔵',
    color: 'var(--accent)',
    status: 'wip',
  },
  {
    id: 'ideate',
    name: 'Ideate',
    className: 'ideate',
    desc: 'Generate AI-assisted ideas and evaluate them.',
    icon: '💡',
    color: 'var(--warning)',
    status: 'wip',
  },
  {
    id: 'prototype',
    name: 'Prototype',
    className: 'prototype',
    desc: 'Working Student Task Planner demo.',
    icon: '🟢',
    color: 'var(--success)',
    status: 'done',
  },
  {
    id: 'validate',
    name: 'Validate',
    className: 'validate',
    desc: 'Collect tester feedback on the prototype.',
    icon: '🟠',
    color: 'var(--orange)',
    status: 'todo',
  },
];

const CHECKLIST = [
  { done: true,  wip: false, text: 'Project scaffolded and running' },
  { done: true,  wip: false, text: 'Dashboard and navigation working' },
  { done: false, wip: true,  text: 'Complete at least 3 real empathy interviews' },
  { done: false, wip: true,  text: 'Finalise problem statement in Define stage' },
  { done: false, wip: true,  text: 'Review and refine ideation in Ideate stage' },
  { done: true,  wip: false, text: 'Student Task Planner prototype functional' },
  { done: false, wip: false, text: 'Conduct 3 real user validation tests' },
  { done: false, wip: false, text: 'Complete Evidence & Report section' },
];

const ACTIVITY = [
  { time: 'Just now', msg: 'Prototype workspace initialised (Student Task Planner)', icon: '🟢' },
  { time: 'Today',   msg: 'Empathize forms and journey map builder ready', icon: '💜' },
  { time: 'Today',   msg: 'AI Ideation workspace created (demo mode)', icon: '💡' },
  { time: 'Today',   msg: 'Problem Definition editor set up', icon: '🔵' },
];

export default function Dashboard({ navigate }) {
  const [interviews] = useLocalStorage('bt_interviews', []);
  const [tasks]      = useLocalStorage('bt_tasks', []);
  const [ideas]      = useLocalStorage('bt_ideas', []);
  const [feedback]   = useLocalStorage('bt_feedback', []);

  const doneTasks = tasks.filter(t => t.completed).length;

  return (
    <div>
      {/* Hero */}
      <div style={{ marginBottom: 32 }}>
        <div style={{
          display:'flex', alignItems:'center', gap:12, marginBottom:14,
        }}>
          <div style={{
            width:48, height:48, borderRadius:14,
            background:'linear-gradient(135deg,#0a84ff,#005ecb)',
            display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
            </svg>
          </div>
          <div>
            <h1 className="page-title">Project Better Tomorrow</h1>
            <p className="page-subtitle">
              AI-Powered Design Thinking Solution &mdash; Milestone 1 of 3
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="card" style={{ padding:'18px 22px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <span style={{ fontWeight:700, fontSize:'0.9rem' }}>Overall Project Progress</span>
            <span style={{ fontSize:'1.3rem', fontWeight:800, color:'var(--accent)' }}>35%</span>
          </div>
          <div className="progress-track">
            <div className="progress-fill" style={{ width:'35%' }} />
          </div>
          <p style={{ marginTop:8, fontSize:'0.75rem', color:'var(--text-muted)' }}>
            Milestone 1 complete · Empathy data collection, ideation &amp; validation in progress
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--purple-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--purple)" strokeWidth="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
          </div>
          <div className="stat-value">{interviews.length}</div>
          <div className="stat-label">Interviews / Obs.</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--accent-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
          </div>
          <div className="stat-value">{ideas.length}</div>
          <div className="stat-label">Ideas Generated</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--success-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="2">
              <polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>
            </svg>
          </div>
          <div className="stat-value">{tasks.length}</div>
          <div className="stat-label">Prototype Tasks</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--orange-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--orange)" strokeWidth="2">
              <polyline points="9 11 12 14 22 4"/>
              <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
            </svg>
          </div>
          <div className="stat-value">{feedback.length}</div>
          <div className="stat-label">Tester Responses</div>
        </div>
      </div>

      {/* Stage cards */}
      <h2 className="section-title">Design Thinking Stages</h2>
      <div className="stages-grid">
        {STAGES.map(stage => (
          <div
            key={stage.id}
            className={`stage-card ${stage.className}`}
            onClick={() => navigate(stage.id)}
            role="button"
            tabIndex={0}
            onKeyDown={e => e.key === 'Enter' && navigate(stage.id)}
            aria-label={`Go to ${stage.name} stage`}
          >
            <div className="stage-icon" style={{
              background: `${stage.color}22`,
              color: stage.color,
              fontSize:'1.3rem',
            }}>
              {stage.icon}
            </div>
            <div className="stage-name">{stage.name}</div>
            <div className="stage-desc">{stage.desc}</div>
            <div>
              {stage.status === 'done' && <span className="badge badge-done">✓ Complete</span>}
              {stage.status === 'wip'  && <span className="badge badge-wip">⏳ In Progress</span>}
              {stage.status === 'todo' && <span className="badge badge-todo">○ Pending</span>}
            </div>
          </div>
        ))}
      </div>

      {/* Two-column bottom */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginTop:8 }}>
        {/* Checklist */}
        <div className="card">
          <h2 className="section-title">📋 Next Steps Checklist</h2>
          <ul className="checklist">
            {CHECKLIST.map((item, i) => (
              <li key={i}>
                <span className={`check-icon ${item.done ? 'check-done' : item.wip ? 'check-wip' : 'check-todo'}`}>
                  {item.done ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  ) : item.wip ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                    </svg>
                  ) : (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <circle cx="12" cy="12" r="10"/>
                    </svg>
                  )}
                </span>
                <span className={item.done ? 'strike' : ''}>{item.text}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Recent Activity */}
        <div className="card">
          <h2 className="section-title">🕐 Recent Activity</h2>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {ACTIVITY.map((a, i) => (
              <div key={i} style={{
                display:'flex', alignItems:'flex-start', gap:10,
                padding:'10px 12px',
                background:'var(--bg-elevated)',
                borderRadius:'var(--radius-sm)',
              }}>
                <span style={{ fontSize:'1rem', flexShrink:0 }}>{a.icon}</span>
                <div>
                  <div style={{ fontSize:'0.82rem', color:'var(--text-primary)', lineHeight:1.4 }}>{a.msg}</div>
                  <div style={{ fontSize:'0.7rem', color:'var(--text-muted)', marginTop:2 }}>{a.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="card" style={{ marginTop:16 }}>
        <h2 className="section-title">⚡ Quick Actions</h2>
        <div style={{ display:'flex', flexWrap:'wrap', gap:10 }}>
          {[
            { label:'Add Interview', page:'empathize', color:'var(--purple)' },
            { label:'Edit Problem Statement', page:'define', color:'var(--accent)' },
            { label:'Generate Ideas', page:'ideate', color:'var(--warning)' },
            { label:'Open Task Planner', page:'prototype', color:'var(--success)' },
            { label:'Add Tester Feedback', page:'validate', color:'var(--orange)' },
            { label:'View Report', page:'report', color:'var(--text-secondary)' },
          ].map(a => (
            <button
              key={a.page}
              className="btn btn-secondary"
              onClick={() => navigate(a.page)}
              style={{ borderColor: `${a.color}40` }}
            >
              <span style={{ color:a.color, fontSize:'0.75rem' }}>▶</span>
              {a.label}
            </button>
          ))}
        </div>
      </div>

      {/* Milestone disclaimer */}
      <div className="alert alert-info" style={{ marginTop:20 }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
          <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="8"/><line x1="12" y1="12" x2="12" y2="16"/>
        </svg>
        <span>
          <strong>Milestone 1 (35%):</strong> Infrastructure, empathy forms, problem editor, AI ideation workspace,
          and working prototype are implemented. User validation, AI API integration, and final report remain for
          Milestones 2 &amp; 3.
        </span>
      </div>
    </div>
  );
}
