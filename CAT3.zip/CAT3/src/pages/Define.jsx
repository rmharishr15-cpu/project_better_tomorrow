import { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const DEFAULT_STATEMENT = {
  userGroup: '',
  userNeed: '',
  insight: '',
};

const DEFAULT_WHY = ['', '', '', '', ''];

const DEFAULT_HMW = '';

const SAMPLE_INSIGHTS = [
  { id:'s1', _sample:true, text:'[SAMPLE] Students struggle to remember multiple assignment deadlines across different subjects.', source:'Interview P01 (Illustrative)' },
  { id:'s2', _sample:true, text:'[SAMPLE] Existing tools are either too complex or require too much initial setup.', source:'Observation log #1 (Illustrative)' },
  { id:'s3', _sample:true, text:'[SAMPLE] Cognitive overload during exam periods leads to missed tasks.', source:'Interview P02 (Illustrative)' },
];

function validate(ps) {
  const errs = {};
  if (!ps.userGroup.trim()) errs.userGroup = 'User group is required.';
  if (!ps.userNeed.trim()) errs.userNeed = 'User need is required.';
  if (!ps.insight.trim()) errs.insight = 'Research-supported insight is required.';
  return errs;
}

export default function Define() {
  const [tab, setTab] = useState('statement');
  const [problemStatement, setProblemStatement] = useLocalStorage('bt_problem_statement', DEFAULT_STATEMENT);
  const [whyChain, setWhyChain] = useLocalStorage('bt_why_chain', DEFAULT_WHY);
  const [hmw, setHmw] = useLocalStorage('bt_hmw', DEFAULT_HMW);
  const [insights, setInsights] = useLocalStorage('bt_insights', []);
  const [newInsight, setNewInsight] = useState({ text:'', source:'' });
  const [statementErrors, setStatementErrors] = useState({});
  const [saved, setSaved] = useState(false);
  const [showSample, setShowSample] = useState(false);

  function saveStatement(e) {
    e.preventDefault();
    const errs = validate(problemStatement);
    if (Object.keys(errs).length) { setStatementErrors(errs); return; }
    setStatementErrors({});
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  function addInsight(e) {
    e.preventDefault();
    if (!newInsight.text.trim()) return;
    setInsights(prev => [{ ...newInsight, id: Date.now().toString(36) }, ...prev]);
    setNewInsight({ text:'', source:'' });
  }

  function deleteInsight(id) {
    setInsights(prev => prev.filter(i => i.id !== id));
  }

  function updateWhy(idx, val) {
    setWhyChain(prev => prev.map((v, i) => i === idx ? val : v));
  }

  const allInsights = showSample ? [...SAMPLE_INSIGHTS, ...insights] : insights;

  const fullStatement = problemStatement.userGroup && problemStatement.userNeed && problemStatement.insight
    ? `"${problemStatement.userGroup} needs a way to ${problemStatement.userNeed} because ${problemStatement.insight}."`
    : null;

  return (
    <div>
      <div style={{ marginBottom:24 }}>
        <h1 className="page-title">🔵 Define the Problem</h1>
        <p className="page-subtitle">
          Synthesise your empathy research into a clear, evidence-backed problem statement.
        </p>
      </div>

      <div className="alert alert-orange" style={{ marginBottom:20 }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
          <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
        <span>
          All content here must be derived from real research. Sample labels are illustrative only.
        </span>
      </div>

      <div className="tab-nav">
        {[
          { id:'statement', label:'📝 Problem Statement' },
          { id:'insights', label:'💡 Research Insights' },
          { id:'whywhy', label:'🔍 Why-Why Analysis' },
          { id:'hmw', label:'🤔 How Might We' },
        ].map(t => (
          <button key={t.id} className={`tab-btn ${tab===t.id?'active':''}`} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Problem statement */}
      {tab === 'statement' && (
        <div>
          {fullStatement && (
            <div className="card" style={{ marginBottom:18, borderColor:'var(--accent-border)', background:'var(--accent-dim)' }}>
              <div style={{ fontSize:'0.72rem', fontWeight:700, color:'var(--accent-light)', textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:8 }}>
                Current Problem Statement
              </div>
              <p style={{ fontSize:'1rem', fontWeight:600, color:'var(--text-primary)', fontStyle:'italic', lineHeight:1.6 }}>
                {fullStatement}
              </p>
              {!problemStatement.userGroup && (
                <p className="text-sm text-muted" style={{ marginTop:8 }}>⚠ Not yet derived from real research.</p>
              )}
            </div>
          )}

          <div className="card">
            <h2 className="section-title">Edit Problem Statement</h2>
            <p className="text-sm text-muted" style={{ marginBottom:16 }}>
              Format: <em>&quot;[User group] needs a way to [need] because [research-supported insight].&quot;</em>
            </p>
            <form onSubmit={saveStatement} noValidate>
              <div className="form-group">
                <label className="label" htmlFor="ug">Specific User Group *</label>
                <input
                  id="ug"
                  className="form-input"
                  placeholder="e.g. First-year college students with multiple subjects"
                  value={problemStatement.userGroup}
                  onChange={e => setProblemStatement(p => ({ ...p, userGroup: e.target.value }))}
                />
                {statementErrors.userGroup && <div className="form-error">{statementErrors.userGroup}</div>}
              </div>
              <div className="form-group">
                <label className="label" htmlFor="un">User Need *</label>
                <input
                  id="un"
                  className="form-input"
                  placeholder="e.g. track assignment deadlines across all subjects in one place"
                  value={problemStatement.userNeed}
                  onChange={e => setProblemStatement(p => ({ ...p, userNeed: e.target.value }))}
                />
                {statementErrors.userNeed && <div className="form-error">{statementErrors.userNeed}</div>}
              </div>
              <div className="form-group">
                <label className="label" htmlFor="ins">Research-Supported Insight *</label>
                <textarea
                  id="ins"
                  className="form-textarea"
                  placeholder="e.g. their current methods (sticky notes, memory) cause missed deadlines and stress — observed in 3 interviews"
                  value={problemStatement.insight}
                  onChange={e => setProblemStatement(p => ({ ...p, insight: e.target.value }))}
                />
                {statementErrors.insight && <div className="form-error">{statementErrors.insight}</div>}
                <div className="form-hint">Link this to specific interview or observation records from the Empathize stage.</div>
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                <button type="submit" className="btn btn-primary">Save Statement</button>
                {saved && (
                  <span style={{ color:'var(--success)', fontSize:'0.85rem', display:'flex', alignItems:'center', gap:5 }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                    Saved
                  </span>
                )}
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Research Insights */}
      {tab === 'insights' && (
        <div>
          <div className="card" style={{ marginBottom:18 }}>
            <h2 className="section-title">Add Research Insight</h2>
            <form onSubmit={addInsight} style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
              <div style={{ flex:'2 1 260px' }}>
                <input
                  className="form-input"
                  placeholder="Insight derived from real research..."
                  value={newInsight.text}
                  onChange={e => setNewInsight(n => ({ ...n, text: e.target.value }))}
                />
              </div>
              <div style={{ flex:'1 1 160px' }}>
                <input
                  className="form-input"
                  placeholder="Source (e.g. Interview P02)"
                  value={newInsight.source}
                  onChange={e => setNewInsight(n => ({ ...n, source: e.target.value }))}
                />
              </div>
              <button type="submit" className="btn btn-primary">Add</button>
            </form>
          </div>

          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
            <h2 className="section-title" style={{ marginBottom:0 }}>Insights ({insights.length} real)</h2>
            <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer', fontSize:'0.8rem', color:'var(--text-secondary)' }}>
              <input type="checkbox" checked={showSample} onChange={e => setShowSample(e.target.checked)} />
              Show sample
            </label>
          </div>

          {allInsights.length === 0 ? (
            <div className="empty-state card">
              <h3>No insights added yet</h3>
              <p>Add your first research insight above after completing interviews.</p>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {allInsights.map(ins => (
                <div key={ins.id} className="card" style={{
                  display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:12,
                  border: ins._sample ? '1px solid rgba(255,159,10,0.35)' : undefined,
                  padding:'14px 16px',
                }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:'0.87rem', color:'var(--text-primary)', lineHeight:1.5 }}>{ins.text}</div>
                    {ins.source && (
                      <div style={{ fontSize:'0.72rem', color:'var(--text-muted)', marginTop:4 }}>Source: {ins.source}</div>
                    )}
                    {ins._sample && <span className="badge badge-sample" style={{ marginTop:6 }}>⚠ SAMPLE — NOT REAL</span>}
                  </div>
                  {!ins._sample && (
                    <button className="btn btn-danger btn-sm" onClick={() => deleteInsight(ins.id)}>Del</button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Why-Why analysis */}
      {tab === 'whywhy' && (
        <div>
          <div className="alert alert-info" style={{ marginBottom:16 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="8"/><line x1="12" y1="12" x2="12" y2="16"/>
            </svg>
            <span>
              Start with your problem symptom, then ask &ldquo;Why?&rdquo; five times to reach the root cause.
              Base each answer on actual research evidence.
            </span>
          </div>
          <div className="card">
            <h2 className="section-title">Why-Why (5 Whys) Analysis</h2>
            {whyChain.map((val, idx) => (
              <div key={idx} className="why-row">
                {idx > 0 && (
                  <div style={{ width:2, background:'var(--accent-border)', margin:'0 20px 0 18px', alignSelf:'stretch' }} />
                )}
                <div style={{ flex:1 }}>
                  <label className="label" htmlFor={`why${idx}`} style={{ color:'var(--accent-light)' }}>
                    {idx === 0 ? '🔴 Problem Symptom' : `Why ${idx}?`}
                  </label>
                  <textarea
                    id={`why${idx}`}
                    className="form-textarea"
                    style={{ minHeight:60 }}
                    placeholder={idx === 0
                      ? 'Describe the observable problem…'
                      : `Why does "${truncateWhy(whyChain[idx-1])}" happen?`}
                    value={val}
                    onChange={e => updateWhy(idx, e.target.value)}
                  />
                </div>
              </div>
            ))}
            <p className="text-sm text-muted" style={{ marginTop:8 }}>Changes saved automatically to browser storage.</p>
          </div>
        </div>
      )}

      {/* How Might We */}
      {tab === 'hmw' && (
        <div>
          <div className="card">
            <h2 className="section-title">How Might We…</h2>
            <p className="text-sm text-muted" style={{ marginBottom:14 }}>
              Reframe your problem statement as an opportunity question.
              Example: &ldquo;How might we help students track deadlines without adding complexity?&rdquo;
            </p>
            <div className="form-group">
              <label className="label" htmlFor="hmwinput">Your HMW Question</label>
              <textarea
                id="hmwinput"
                className="form-textarea"
                placeholder="How might we…"
                value={hmw}
                onChange={e => setHmw(e.target.value)}
                style={{ minHeight:100, fontSize:'1rem', fontStyle:'italic' }}
              />
              <div className="form-hint">Derive from your problem statement and research evidence.</div>
            </div>
            {hmw && (
              <div style={{
                background:'var(--accent-dim)', border:'1px solid var(--accent-border)',
                borderRadius:'var(--radius-sm)', padding:'16px', marginTop:4,
              }}>
                <div style={{ fontSize:'0.72rem', fontWeight:700, color:'var(--accent-light)', marginBottom:6, textTransform:'uppercase' }}>
                  Your HMW Statement
                </div>
                <p style={{ fontSize:'1rem', fontWeight:600, color:'var(--text-primary)', fontStyle:'italic' }}>{hmw}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function truncateWhy(str = '') {
  return str.length > 60 ? str.slice(0, 60) + '…' : str || '…';
}
