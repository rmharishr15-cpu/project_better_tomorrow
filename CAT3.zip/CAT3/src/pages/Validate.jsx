import { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { uid, fmtDate } from '../utils/helpers';

const BLANK_FEEDBACK = {
  participantCode: '', prototypeVersion: 'v1.0', testTask: '',
  completed: '', easeRating: '', workedWell: '', confusing: '',
  suggestion: '', consent: false,
};

const EASE_OPTIONS = [
  { value:'', label:'Select…' },
  { value:'1', label:'1 — Very difficult' },
  { value:'2', label:'2 — Difficult' },
  { value:'3', label:'3 — Neutral' },
  { value:'4', label:'4 — Easy' },
  { value:'5', label:'5 — Very easy' },
];

const COMPLETION_OPTIONS = [
  { value:'', label:'Select…' },
  { value:'yes', label:'Yes — completed successfully' },
  { value:'partial', label:'Partially completed' },
  { value:'no', label:'No — could not complete' },
];

const TEST_SCRIPT = [
  { task:'T1', desc:'Add a new task called "Submit Physics Lab Report" due next Friday, set to High priority.' },
  { task:'T2', desc:'Mark the task you just added as completed.' },
  { task:'T3', desc:'Filter tasks to show only "Overdue" items. What do you see?' },
];

function validate(form) {
  const errs = {};
  if (!form.participantCode.trim()) errs.participantCode = 'Participant code required.';
  if (!form.testTask.trim()) errs.testTask = 'Test task description required.';
  if (!form.completed) errs.completed = 'Completion status required.';
  if (!form.easeRating) errs.easeRating = 'Ease rating required.';
  if (!form.consent) errs.consent = 'Tester consent must be confirmed.';
  return errs;
}

export default function Validate() {
  const [tab, setTab] = useState('form');
  const [feedback, setFeedback] = useLocalStorage('bt_feedback', []);
  const [form, setForm] = useState({ ...BLANK_FEEDBACK });
  const [errors, setErrors] = useState({});
  const [saved, setSaved] = useState(false);

  function submitFeedback(e) {
    e.preventDefault();
    const errs = validate(form);
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setFeedback(prev => [{ ...form, id: uid(), date: new Date().toISOString().split('T')[0] }, ...prev]);
    setForm({ ...BLANK_FEEDBACK });
    setErrors({});
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    setTab('summary');
  }

  function deleteFeedback(id) {
    if (confirm('Delete this feedback record?')) {
      setFeedback(prev => prev.filter(f => f.id !== id));
    }
  }

  const avgEase = feedback.length
    ? (feedback.reduce((s, f) => s + (Number(f.easeRating) || 0), 0) / feedback.length).toFixed(1)
    : null;

  const completionCounts = {
    yes: feedback.filter(f => f.completed === 'yes').length,
    partial: feedback.filter(f => f.completed === 'partial').length,
    no: feedback.filter(f => f.completed === 'no').length,
  };

  return (
    <div>
      <div style={{ marginBottom:24 }}>
        <h1 className="page-title">🟠 Validate</h1>
        <p className="page-subtitle">
          Collect real feedback from actual testers. Use the test script below to guide sessions.
        </p>
      </div>

      <div className="alert alert-orange" style={{ marginBottom:20 }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
          <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
        <span>
          <strong>Data integrity:</strong> Only record responses from real, consenting testers.
          Do not fabricate test completions, ratings, or quotations.
          You need at least 3 real tester records for submission.
        </span>
      </div>

      <div className="tab-nav">
        {[
          { id:'script', label:'📋 Test Script' },
          { id:'form', label:'➕ Record Feedback' },
          { id:'summary', label:`📊 Summary (${feedback.length})` },
        ].map(t => (
          <button key={t.id} className={`tab-btn ${tab===t.id?'active':''}`} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Test script */}
      {tab === 'script' && (
        <div>
          <div className="card" style={{ marginBottom:16 }}>
            <h2 className="section-title">Prototype Test Script</h2>
            <div className="alert alert-info" style={{ marginBottom:16 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
                <circle cx="12" cy="12" r="10"/>
              </svg>
              <span>
                Read this introduction to each tester verbatim:
                <br /><br />
                <em>&ldquo;Thank you for helping with my project. I am testing a student task planner
                prototype. There are no right or wrong answers — I am testing the prototype, not you.
                Please think aloud as you work through each task. Your feedback is anonymous and will
                be used only for this student project.&rdquo;</em>
              </span>
            </div>

            <h3 className="section-title" style={{ fontSize:'0.9rem' }}>Tasks to Complete</h3>
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {TEST_SCRIPT.map(t => (
                <div key={t.task} style={{
                  background:'var(--bg-elevated)', borderRadius:'var(--radius-sm)',
                  padding:'14px 16px', display:'flex', gap:14,
                }}>
                  <span style={{ fontWeight:800, color:'var(--accent)', minWidth:28, fontSize:'0.9rem' }}>{t.task}</span>
                  <span style={{ fontSize:'0.88rem', color:'var(--text-primary)', lineHeight:1.5 }}>{t.desc}</span>
                </div>
              ))}
            </div>

            <div className="divider" />
            <h3 className="section-title" style={{ fontSize:'0.9rem' }}>Closing Questions</h3>
            <ul style={{ listStyle:'disc', paddingLeft:20, display:'flex', flexDirection:'column', gap:6 }}>
              {[
                'What did you find most useful about the planner?',
                'Was anything confusing or unclear?',
                'What one change would make this most useful to you?',
                'Would you use a tool like this for your own studies? Why or why not?',
              ].map((q, i) => (
                <li key={i} style={{ fontSize:'0.87rem', color:'var(--text-secondary)' }}>{q}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Feedback form */}
      {tab === 'form' && (
        <div>
          {saved && (
            <div className="alert alert-success" style={{ marginBottom:16 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              Feedback saved successfully! Record feedback from your next tester.
            </div>
          )}
          <div className="card">
            <h2 className="section-title">Record Tester Feedback</h2>
            <form onSubmit={submitFeedback} noValidate>
              <div className="form-grid form-grid-2">
                <div className="form-group">
                  <label className="label" htmlFor="vpc">Participant Code *</label>
                  <input
                    id="vpc"
                    className="form-input"
                    placeholder="e.g. T01 (anonymised)"
                    value={form.participantCode}
                    onChange={e => setForm(f => ({ ...f, participantCode: e.target.value }))}
                  />
                  {errors.participantCode && <div className="form-error">{errors.participantCode}</div>}
                </div>
                <div className="form-group">
                  <label className="label" htmlFor="vpv">Prototype Version</label>
                  <input
                    id="vpv"
                    className="form-input"
                    value={form.prototypeVersion}
                    onChange={e => setForm(f => ({ ...f, prototypeVersion: e.target.value }))}
                  />
                </div>
              </div>
              <div className="form-group">
                <label className="label" htmlFor="vtt">Test Task(s) Attempted *</label>
                <textarea
                  id="vtt"
                  className="form-textarea"
                  placeholder="Which tasks from the test script did this tester attempt?"
                  value={form.testTask}
                  onChange={e => setForm(f => ({ ...f, testTask: e.target.value }))}
                  style={{ minHeight:60 }}
                />
                {errors.testTask && <div className="form-error">{errors.testTask}</div>}
              </div>
              <div className="form-grid form-grid-2">
                <div className="form-group">
                  <label className="label" htmlFor="vcs">Completion Status *</label>
                  <select
                    id="vcs"
                    className="form-select"
                    value={form.completed}
                    onChange={e => setForm(f => ({ ...f, completed: e.target.value }))}
                  >
                    {COMPLETION_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                  {errors.completed && <div className="form-error">{errors.completed}</div>}
                </div>
                <div className="form-group">
                  <label className="label" htmlFor="ver">Ease of Use Rating (1–5) *</label>
                  <select
                    id="ver"
                    className="form-select"
                    value={form.easeRating}
                    onChange={e => setForm(f => ({ ...f, easeRating: e.target.value }))}
                  >
                    {EASE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                  {errors.easeRating && <div className="form-error">{errors.easeRating}</div>}
                </div>
              </div>
              {[
                { id:'vww', field:'workedWell', label:'What worked well?', ph:'Features or interactions the tester found helpful' },
                { id:'vcf', field:'confusing', label:'What was confusing?', ph:'Anything the tester struggled with or found unclear' },
                { id:'vsug', field:'suggestion', label:'Suggested improvement', ph:'Any specific change the tester recommended' },
              ].map(row => (
                <div key={row.id} className="form-group">
                  <label className="label" htmlFor={row.id}>{row.label}</label>
                  <textarea
                    id={row.id}
                    className="form-textarea"
                    placeholder={row.ph}
                    value={form[row.field]}
                    onChange={e => setForm(f => ({ ...f, [row.field]: e.target.value }))}
                    style={{ minHeight:65 }}
                  />
                </div>
              ))}
              <div className="form-group">
                <label style={{ display:'flex', alignItems:'flex-start', gap:10, cursor:'pointer' }}>
                  <input
                    type="checkbox"
                    checked={form.consent}
                    onChange={e => setForm(f => ({ ...f, consent: e.target.checked }))}
                    style={{ marginTop:3 }}
                  />
                  <span style={{ fontSize:'0.82rem', color:'var(--text-secondary)' }}>
                    The tester verbally confirmed they understand their feedback will be used
                    for this student project and that participation is voluntary.
                  </span>
                </label>
                {errors.consent && <div className="form-error">{errors.consent}</div>}
              </div>
              <button type="submit" className="btn btn-primary">Save Feedback</button>
            </form>
          </div>
        </div>
      )}

      {/* Summary */}
      {tab === 'summary' && (
        <div>
          {feedback.length < 3 && (
            <div className="alert alert-warning" style={{ marginBottom:16 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
              </svg>
              <span>
                You have {feedback.length} of 3 required tester records.
                Collect {3 - feedback.length} more before submission.
              </span>
            </div>
          )}

          {/* Stats */}
          <div className="stats-row" style={{ marginBottom:20 }}>
            <div className="stat-card">
              <div className="stat-value">{feedback.length}</div>
              <div className="stat-label">Testers</div>
            </div>
            <div className="stat-card">
              <div className="stat-value" style={{ color: avgEase >= 4 ? 'var(--success)' : avgEase >= 3 ? 'var(--warning)' : 'var(--danger)' }}>
                {avgEase ?? '—'}
              </div>
              <div className="stat-label">Avg Ease (/ 5)</div>
            </div>
            <div className="stat-card">
              <div className="stat-value" style={{ color:'var(--success)' }}>{completionCounts.yes}</div>
              <div className="stat-label">Fully Completed</div>
            </div>
            <div className="stat-card">
              <div className="stat-value" style={{ color:'var(--warning)' }}>{completionCounts.partial}</div>
              <div className="stat-label">Partial</div>
            </div>
          </div>

          {feedback.length === 0 ? (
            <div className="empty-state card">
              <h3>No feedback recorded yet</h3>
              <p>Use the &ldquo;Record Feedback&rdquo; tab to add real tester responses.</p>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
              {feedback.map((fb, idx) => (
                <div key={fb.id} className="card">
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <span style={{ fontWeight:700 }}>Tester {idx + 1}: {fb.participantCode}</span>
                      <span className="badge badge-info">v{fb.prototypeVersion}</span>
                      <span className="badge badge-info">Ease: {fb.easeRating}/5</span>
                      <span className={`badge ${fb.completed === 'yes' ? 'badge-done' : fb.completed === 'partial' ? 'badge-wip' : 'badge-danger'}`}>
                        {COMPLETION_OPTIONS.find(o => o.value === fb.completed)?.label?.replace('—','').trim() || fb.completed}
                      </span>
                    </div>
                    <button className="btn btn-danger btn-sm" onClick={() => deleteFeedback(fb.id)}>Delete</button>
                  </div>
                  <div className="form-grid form-grid-2" style={{ gap:10 }}>
                    {[
                      { label:'Worked Well', val:fb.workedWell, color:'var(--success)' },
                      { label:'Confusing', val:fb.confusing, color:'var(--danger)' },
                      { label:'Suggestion', val:fb.suggestion, color:'var(--warning)' },
                      { label:'Tasks Attempted', val:fb.testTask, color:'var(--text-muted)' },
                    ].map(row => (
                      <div key={row.label} style={{
                        background:'var(--bg-elevated)', borderRadius:'var(--radius-sm)',
                        padding:'10px 12px',
                      }}>
                        <div style={{ fontSize:'0.68rem', fontWeight:700, color: row.color, textTransform:'uppercase', marginBottom:4 }}>
                          {row.label}
                        </div>
                        <div style={{ fontSize:'0.82rem', color:'var(--text-secondary)' }}>
                          {row.val || <em style={{ color:'var(--text-muted)' }}>Not provided</em>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
