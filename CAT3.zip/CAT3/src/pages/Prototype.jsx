import { useState, useMemo } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { uid, fmtDate, isOverdue, PRIORITIES, SUBJECTS } from '../utils/helpers';

const BLANK_TASK = {
  id: '', title: '', subject: 'Computer Science', priority: 'medium',
  dueDate: '', completed: false, notes: '',
};

function validate(form) {
  const errs = {};
  if (!form.title.trim()) errs.title = 'Task title is required.';
  if (!form.dueDate) errs.dueDate = 'Due date is required.';
  return errs;
}

function TaskModal({ task, onSave, onClose }) {
  const [form, setForm] = useState({ ...BLANK_TASK, ...task });
  const [errors, setErrors] = useState({});

  function handleSubmit(e) {
    e.preventDefault();
    const errs = validate(form);
    if (Object.keys(errs).length) { setErrors(errs); return; }
    onSave(form);
  }

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" aria-label="Task editor">
      <div className="modal">
        <div className="modal-header">
          <h2 className="modal-title">{task.id ? 'Edit Task' : 'Add New Task'}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="label" htmlFor="ttitle">Task Title *</label>
            <input
              id="ttitle"
              className="form-input"
              autoFocus
              placeholder="e.g. Complete Lab Report Chapter 3"
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
            />
            {errors.title && <div className="form-error">{errors.title}</div>}
          </div>

          <div className="form-grid form-grid-2">
            <div className="form-group">
              <label className="label" htmlFor="tsubj">Subject *</label>
              <select
                id="tsubj"
                className="form-select"
                value={form.subject}
                onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
              >
                {SUBJECTS.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="label" htmlFor="tpri">Priority</label>
              <select
                id="tpri"
                className="form-select"
                value={form.priority}
                onChange={e => setForm(f => ({ ...f, priority: e.target.value }))}
              >
                {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label className="label" htmlFor="tdue">Due Date *</label>
            <input
              id="tdue"
              type="date"
              className="form-input"
              value={form.dueDate}
              onChange={e => setForm(f => ({ ...f, dueDate: e.target.value }))}
            />
            {errors.dueDate && <div className="form-error">{errors.dueDate}</div>}
          </div>

          <div className="form-group">
            <label className="label" htmlFor="tnotes">Notes (optional)</label>
            <textarea
              id="tnotes"
              className="form-textarea"
              placeholder="Any additional context or sub-tasks"
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              style={{ minHeight:70 }}
            />
          </div>

          <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}>
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary">
              {task.id ? 'Save Changes' : 'Add Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function Prototype() {
  const [tasks, setTasks] = useLocalStorage('bt_tasks', []);
  const [editingTask, setEditingTask] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterSubject, setFilterSubject] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');

  /* Stats */
  const total = tasks.length;
  const completed = tasks.filter(t => t.completed).length;
  const pending = total - completed;
  const overdue = tasks.filter(t => !t.completed && isOverdue(t.dueDate)).length;

  /* Filter */
  const filtered = useMemo(() => {
    return tasks.filter(t => {
      if (filterStatus === 'pending' && t.completed) return false;
      if (filterStatus === 'completed' && !t.completed) return false;
      if (filterStatus === 'overdue' && (t.completed || !isOverdue(t.dueDate))) return false;
      if (filterSubject !== 'all' && t.subject !== filterSubject) return false;
      if (filterPriority !== 'all' && t.priority !== filterPriority) return false;
      return true;
    }).sort((a, b) => {
      // sort: pending overdue first, then by due date asc
      const aOD = !a.completed && isOverdue(a.dueDate);
      const bOD = !b.completed && isOverdue(b.dueDate);
      if (aOD && !bOD) return -1;
      if (!aOD && bOD) return 1;
      return new Date(a.dueDate) - new Date(b.dueDate);
    });
  }, [tasks, filterStatus, filterSubject, filterPriority]);

  const subjects = ['all', ...new Set(tasks.map(t => t.subject))];

  function toggleComplete(id) {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  }

  function saveTask(form) {
    if (form.id) {
      setTasks(prev => prev.map(t => t.id === form.id ? form : t));
    } else {
      setTasks(prev => [{ ...form, id: uid() }, ...prev]);
    }
    setEditingTask(null);
  }

  function deleteTask(id) {
    if (confirm('Delete this task?')) {
      setTasks(prev => prev.filter(t => t.id !== id));
    }
  }

  return (
    <div>
      {/* Modal */}
      {editingTask !== null && (
        <TaskModal
          task={editingTask}
          onSave={saveTask}
          onClose={() => setEditingTask(null)}
        />
      )}

      <div style={{ marginBottom:24 }}>
        <h1 className="page-title">🟢 Prototype — Student Task Planner</h1>
        <p className="page-subtitle">
          A working clickable prototype for the provisional problem: managing academic deadlines.
        </p>
      </div>

      <div className="alert alert-orange" style={{ marginBottom:16 }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
          <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
        <span>
          <strong>Provisional prototype.</strong> This example problem (&ldquo;tracking college deadlines&rdquo;) and prototype
          concept have NOT been validated by real user research. Replace with your confirmed problem
          and solution after completing the Empathize and Define stages.
        </span>
      </div>

      {/* Stats */}
      <div className="stats-row" style={{ marginBottom:20 }}>
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--accent-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
              <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
          </div>
          <div className="stat-value">{total}</div>
          <div className="stat-label">Total Tasks</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--warning-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--warning)" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
          </div>
          <div className="stat-value">{pending}</div>
          <div className="stat-label">Pending</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--success-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="2">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </div>
          <div className="stat-value">{completed}</div>
          <div className="stat-label">Completed</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background:'var(--danger-dim)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--danger)" strokeWidth="2">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
            </svg>
          </div>
          <div className="stat-value" style={{ color: overdue > 0 ? 'var(--danger)' : 'var(--text-primary)' }}>
            {overdue}
          </div>
          <div className="stat-label">Overdue</div>
        </div>
      </div>

      {/* Toolbar */}
      <div style={{ display:'flex', flexWrap:'wrap', gap:10, marginBottom:18, alignItems:'center' }}>
        <button className="btn btn-primary" onClick={() => setEditingTask({ ...BLANK_TASK })}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
          Add Task
        </button>

        <select
          className="form-select"
          style={{ width:'auto' }}
          value={filterStatus}
          onChange={e => setFilterStatus(e.target.value)}
          aria-label="Filter by status"
        >
          <option value="all">All statuses</option>
          <option value="pending">Pending</option>
          <option value="completed">Completed</option>
          <option value="overdue">Overdue</option>
        </select>

        <select
          className="form-select"
          style={{ width:'auto' }}
          value={filterSubject}
          onChange={e => setFilterSubject(e.target.value)}
          aria-label="Filter by subject"
        >
          <option value="all">All subjects</option>
          {SUBJECTS.map(s => <option key={s}>{s}</option>)}
        </select>

        <select
          className="form-select"
          style={{ width:'auto' }}
          value={filterPriority}
          onChange={e => setFilterPriority(e.target.value)}
          aria-label="Filter by priority"
        >
          <option value="all">All priorities</option>
          {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>

        {(filterStatus !== 'all' || filterSubject !== 'all' || filterPriority !== 'all') && (
          <button className="btn btn-ghost btn-sm" onClick={() => {
            setFilterStatus('all'); setFilterSubject('all'); setFilterPriority('all');
          }}>
            Clear filters
          </button>
        )}

        <span className="text-muted text-sm" style={{ marginLeft:'auto' }}>
          Showing {filtered.length} of {total}
        </span>
      </div>

      {/* Task list */}
      {filtered.length === 0 ? (
        <div className="empty-state card">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
          <h3>{tasks.length === 0 ? 'No tasks yet' : 'No tasks match your filters'}</h3>
          <p>
            {tasks.length === 0
              ? 'Click "Add Task" to create your first academic task.'
              : 'Try clearing the filters to see all tasks.'}
          </p>
          {tasks.length === 0 && (
            <button className="btn btn-primary" style={{ marginTop:16 }} onClick={() => setEditingTask({ ...BLANK_TASK })}>
              Add Task
            </button>
          )}
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {filtered.map(task => {
            const overdueFlag = !task.completed && isOverdue(task.dueDate);
            return (
              <div key={task.id} className={`task-card ${overdueFlag ? 'overdue' : ''} ${task.completed ? 'completed' : ''}`}>
                {/* Checkbox */}
                <button
                  className={`task-checkbox ${task.completed ? 'checked' : ''}`}
                  onClick={() => toggleComplete(task.id)}
                  aria-label={task.completed ? 'Mark pending' : 'Mark complete'}
                  title={task.completed ? 'Mark as pending' : 'Mark as complete'}
                >
                  {task.completed && (
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  )}
                </button>

                {/* Content */}
                <div style={{ flex:1, minWidth:0 }}>
                  <div className="task-title">{task.title}</div>
                  <div className="task-meta">
                    <span>
                      <span className={`priority-dot ${PRIORITIES[task.priority]?.className}`} />
                      {PRIORITIES[task.priority]?.label}
                    </span>
                    <span>📚 {task.subject}</span>
                    <span style={{ color: overdueFlag ? 'var(--danger)' : 'var(--text-muted)' }}>
                      {overdueFlag ? '⚠ Overdue · ' : ''}
                      Due {fmtDate(task.dueDate)}
                    </span>
                    {task.completed && <span style={{ color:'var(--success)' }}>✓ Done</span>}
                  </div>
                  {task.notes && (
                    <div style={{ fontSize:'0.78rem', color:'var(--text-muted)', marginTop:5, lineHeight:1.4 }}>
                      {task.notes}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div style={{ display:'flex', gap:6, flexShrink:0 }}>
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={() => setEditingTask(task)}
                    aria-label="Edit task"
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                    </svg>
                    Edit
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => deleteTask(task.id)}
                    aria-label="Delete task"
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                      <path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/>
                    </svg>
                    Del
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Progress bar */}
      {total > 0 && (
        <div className="card" style={{ marginTop:20 }}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
            <span style={{ fontSize:'0.85rem', fontWeight:600 }}>Overall Completion</span>
            <span style={{ fontSize:'0.85rem', color:'var(--text-muted)' }}>
              {completed}/{total} tasks
            </span>
          </div>
          <div className="progress-track">
            <div
              className={`progress-fill ${completed === total ? 'success' : ''}`}
              style={{ width: total > 0 ? `${(completed / total) * 100}%` : '0%' }}
            />
          </div>
          <div style={{ marginTop:8, fontSize:'0.75rem', color:'var(--text-muted)' }}>
            {Math.round((completed / total) * 100)}% complete
            {overdue > 0 && <span style={{ color:'var(--danger)', marginLeft:12 }}>⚠ {overdue} task(s) overdue</span>}
          </div>
        </div>
      )}

      <div className="alert alert-info" style={{ marginTop:18 }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
          <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="8"/><line x1="12" y1="12" x2="12" y2="16"/>
        </svg>
        <span>
          Tasks are saved to your browser&apos;s local storage. No account or internet connection is required.
        </span>
      </div>
    </div>
  );
}
