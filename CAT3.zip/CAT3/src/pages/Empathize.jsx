import { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { uid, fmtDate, truncate } from '../utils/helpers';

const BLANK_INTERVIEW = {
  id: '', participantCode: '', participantType: 'Student', date: '',
  q1: '', a1: '', q2: '', a2: '', q3: '', a3: '', painPoints: '', notes: '',
};

const BLANK_OBS = {
  id: '', date: '', context: '', observedBehavior: '', frictionPoint: '', evidenceNotes: '',
};

const BLANK_JOURNEY_STAGE = { stage: '', action: '', thought: '', emotion: '', painPoint: '' };

const PARTICIPANT_TYPES = ['Student', 'Teacher', 'Parent', 'Administrator', 'Other'];

const SAMPLE_INTERVIEW = {
  id: 'sample-1',
  _isSample: true,
  participantCode: 'SAMPLE-P01',
  participantType: 'Student',
  date: '2024-01-15',
  q1: 'How do you currently track your assignments?',
  a1: '[SAMPLE] I use a mix of my phone notes and memory — I often forget things.',
  q2: 'What is the most frustrating part of managing academic tasks?',
  a2: '[SAMPLE] Missing deadlines because I did not realise when they were due.',
  q3: 'Have you tried any tools? What happened?',
  a3: '[SAMPLE] Tried a planner app but stopped using it because setup was too complex.',
  painPoints: '[SAMPLE] Deadline tracking, multi-subject complexity, cognitive overload.',
  notes: '[SAMPLE] Illustrative only. Replace with data from real interviews.',
};

function validate(form, type) {
  const errors = {};
  if (type === 'interview') {
    if (!form.participantCode.trim()) errors.participantCode = 'Participant code is required.';
    if (!form.date) errors.date = 'Date is required.';
    if (!form.q1.trim()) errors.q1 = 'At least one question is required.';
    if (!form.a1.trim()) errors.a1 = 'At least one response is required.';
  }
  if (type === 'obs') {
    if (!form.date) errors.date = 'Date is required.';
    if (!form.context.trim()) errors.context = 'Context is required.';
    if (!form.observedBehavior.trim()) errors.observedBehavior = 'Observed behaviour is required.';
  }
  return errors;
}

export default function Empathize() {
  const [tab, setTab] = useState('interviews');
  const [interviews, setInterviews] = useLocalStorage('bt_interviews', []);
  const [observations, setObservations] = useLocalStorage('bt_observations', []);
  const [journeyStages, setJourneyStages] = useLocalStorage('bt_journey', [
    { ...BLANK_JOURNEY_STAGE, stage: 'Awareness', id: uid() },
    { ...BLANK_JOURNEY_STAGE, stage: 'Planning', id: uid() },
    { ...BLANK_JOURNEY_STAGE, stage: 'Execution', id: uid() },
  ]);

  const [interviewForm, setInterviewForm] = useState({ ...BLANK_INTERVIEW });
  const [obsForm, setObsForm] = useState({ ...BLANK_OBS });
  const [interviewErrors, setInterviewErrors] = useState({});
  const [obsErrors, setObsErrors] = useState({});
  const [viewingInterview, setViewingInterview] = useState(null);
  const [showSample, setShowSample] = useState(false);

  /* ---- Interview handlers ---- */
  function submitInterview(e) {
    e.preventDefault();
    const errs = validate(interviewForm, 'interview');
    if (Object.keys(errs).length) { setInterviewErrors(errs); return; }
    setInterviews(prev => [{ ...interviewForm, id: uid() }, ...prev]);
    setInterviewForm({ ...BLANK_INTERVIEW });
    setInterviewErrors({});
  }

  function deleteInterview(id) {
    if (confirm('Delete this interview record?')) {
      setInterviews(prev => prev.filter(i => i.id !== id));
    }
  }

  /* ---- Observation handlers ---- */
  function submitObs(e) {
    e.preventDefault();
    const errs = validate(obsForm, 'obs');
    if (Object.keys(errs).length) { setObsErrors(errs); return; }
    setObservations(prev => [{ ...obsForm, id: uid() }, ...prev]);
    setObsForm({ ...BLANK_OBS });
    setObsErrors({});
  }

  function deleteObs(id) {
    if (confirm('Delete this observation?')) {
      setObservations(prev => prev.filter(o => o.id !== id));
    }
  }

  /* ---- Journey map handlers ---- */
  function updateJourney(idx, field, val) {
    setJourneyStages(prev => prev.map((s, i) => i === idx ? { ...s, [field]: val } : s));
  }
  function addJourneyStage() {
    setJourneyStages(prev => [...prev, { ...BLANK_JOURNEY_STAGE, id: uid() }]);
  }
  function removeJourneyStage(idx) {
    if (journeyStages.length <= 1) return;
    setJourneyStages(prev => prev.filter((_, i) => i !== idx));
  }

  const allInterviews = showSample ? [SAMPLE_INTERVIEW, ...interviews] : interviews;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">💜 Empathize</h1>
        <p className="page-subtitle">
          Collect authentic user research through interviews, observations, and journey mapping.
        </p>
      </div>

      <div className="alert alert-orange">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
          <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
        <span>
          <strong>Data integrity notice:</strong> Only record real research data here.
          Toggle &ldquo;Show sample&rdquo; to see illustrative examples that are clearly labelled.
          Do not represent sample data as genuine research in your submission.
        </span>
      </div>

      {/* Tabs */}
      <div className="tab-nav">
        {[
          { id:'interviews', label:'📝 Interviews' },
          { id:'observations', label:'👁 Observations' },
          { id:'journey', label:'🗺 Journey Map' },
        ].map(t => (
          <button
            key={t.id}
            className={`tab-btn ${tab === t.id ? 'active' : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ===================== INTERVIEWS ===================== */}
      {tab === 'interviews' && (
        <div>
          {/* Add form */}
          <div className="card" style={{ marginBottom: 20 }}>
            <h2 className="section-title">Add Interview Record</h2>
            <form onSubmit={submitInterview} noValidate>
              <div className="form-grid form-grid-3">
                <div className="form-group">
                  <label className="label" htmlFor="pcode">Participant Code *</label>
                  <input
                    id="pcode"
                    className="form-input"
                    placeholder="e.g. P01"
                    value={interviewForm.participantCode}
                    onChange={e => setInterviewForm(f => ({ ...f, participantCode: e.target.value }))}
                  />
                  {interviewErrors.participantCode && (
                    <div className="form-error">{interviewErrors.participantCode}</div>
                  )}
                </div>
                <div className="form-group">
                  <label className="label" htmlFor="ptype">Participant Type *</label>
                  <select
                    id="ptype"
                    className="form-select"
                    value={interviewForm.participantType}
                    onChange={e => setInterviewForm(f => ({ ...f, participantType: e.target.value }))}
                  >
                    {PARTICIPANT_TYPES.map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="label" htmlFor="idate">Date *</label>
                  <input
                    id="idate"
                    type="date"
                    className="form-input"
                    value={interviewForm.date}
                    onChange={e => setInterviewForm(f => ({ ...f, date: e.target.value }))}
                  />
                  {interviewErrors.date && <div className="form-error">{interviewErrors.date}</div>}
                </div>
              </div>

              {[1, 2, 3].map(n => (
                <div key={n} style={{ marginBottom: 16 }}>
                  <div className="form-grid form-grid-2">
                    <div className="form-group" style={{ marginBottom:0 }}>
                      <label className="label" htmlFor={`q${n}`}>
                        Question {n}{n === 1 ? ' *' : ' (optional)'}
                      </label>
                      <input
                        id={`q${n}`}
                        className="form-input"
                        placeholder={`Interview question ${n}`}
                        value={interviewForm[`q${n}`]}
                        onChange={e => setInterviewForm(f => ({ ...f, [`q${n}`]: e.target.value }))}
                      />
                      {interviewErrors[`q${n}`] && <div className="form-error">{interviewErrors[`q${n}`]}</div>}
                    </div>
                    <div className="form-group" style={{ marginBottom:0 }}>
                      <label className="label" htmlFor={`a${n}`}>
                        Response {n}{n === 1 ? ' *' : ' (optional)'}
                      </label>
                      <input
                        id={`a${n}`}
                        className="form-input"
                        placeholder={`Participant's response`}
                        value={interviewForm[`a${n}`]}
                        onChange={e => setInterviewForm(f => ({ ...f, [`a${n}`]: e.target.value }))}
                      />
                      {interviewErrors[`a${n}`] && <div className="form-error">{interviewErrors[`a${n}`]}</div>}
                    </div>
                  </div>
                </div>
              ))}

              <div className="form-grid form-grid-2">
                <div className="form-group">
                  <label className="label" htmlFor="painpts">Pain Points Noted</label>
                  <textarea
                    id="painpts"
                    className="form-textarea"
                    placeholder="Key pain points the participant mentioned"
                    value={interviewForm.painPoints}
                    onChange={e => setInterviewForm(f => ({ ...f, painPoints: e.target.value }))}
                    style={{ minHeight:70 }}
                  />
                </div>
                <div className="form-group">
                  <label className="label" htmlFor="inotes">Researcher Notes</label>
                  <textarea
                    id="inotes"
                    className="form-textarea"
                    placeholder="Context, body language, follow-up notes"
                    value={interviewForm.notes}
                    onChange={e => setInterviewForm(f => ({ ...f, notes: e.target.value }))}
                    style={{ minHeight:70 }}
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                Save Interview
              </button>
            </form>
          </div>

          {/* Records */}
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <h2 className="section-title" style={{ marginBottom:0 }}>
              Interview Records ({interviews.length} real)
            </h2>
            <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer', fontSize:'0.8rem', color:'var(--text-secondary)' }}>
              <input
                type="checkbox"
                checked={showSample}
                onChange={e => setShowSample(e.target.checked)}
              />
              Show sample data
            </label>
          </div>

          {allInterviews.length === 0 ? (
            <div className="empty-state card">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
              </svg>
              <h3>No interviews recorded yet</h3>
              <p>Fill in the form above to save your first interview.<br/>Enable &ldquo;Show sample data&rdquo; to see an illustrative example.</p>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
              {allInterviews.map(iv => (
                <div
                  key={iv.id}
                  className="card"
                  style={{ border: iv._isSample ? '1px solid rgba(255,159,10,0.35)' : undefined }}
                >
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:8 }}>
                    <div>
                      <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
                        <span style={{ fontWeight:700, color:'var(--text-primary)' }}>{iv.participantCode}</span>
                        <span className="badge badge-info">{iv.participantType}</span>
                        {iv._isSample && <span className="badge badge-sample">⚠ SAMPLE — NOT REAL</span>}
                        <span className="text-muted text-sm">{fmtDate(iv.date)}</span>
                      </div>
                    </div>
                    <div style={{ display:'flex', gap:8 }}>
                      <button
                        className="btn btn-ghost btn-sm"
                        onClick={() => setViewingInterview(viewingInterview?.id === iv.id ? null : iv)}
                      >
                        {viewingInterview?.id === iv.id ? 'Collapse' : 'View'}
                      </button>
                      {!iv._isSample && (
                        <button className="btn btn-danger btn-sm" onClick={() => deleteInterview(iv.id)}>
                          Delete
                        </button>
                      )}
                    </div>
                  </div>

                  {viewingInterview?.id === iv.id && (
                    <div style={{ marginTop:14 }}>
                      <div className="divider" style={{ margin:'12px 0' }} />
                      {[1,2,3].map(n => iv[`q${n}`] && (
                        <div key={n} style={{ marginBottom:12 }}>
                          <div style={{ fontSize:'0.78rem', fontWeight:700, color:'var(--accent-light)', marginBottom:3 }}>Q{n}: {iv[`q${n}`]}</div>
                          <div style={{ fontSize:'0.85rem', color:'var(--text-secondary)', background:'var(--bg-elevated)', padding:'8px 12px', borderRadius:'var(--radius-sm)' }}>
                            {iv[`a${n}`] || <em style={{color:'var(--text-muted)'}}>No response recorded</em>}
                          </div>
                        </div>
                      ))}
                      {iv.painPoints && (
                        <div style={{ marginBottom:8 }}>
                          <div style={{ fontSize:'0.78rem', fontWeight:700, color:'var(--danger)', marginBottom:3 }}>Pain Points</div>
                          <div className="text-sm" style={{ color:'var(--text-secondary)' }}>{iv.painPoints}</div>
                        </div>
                      )}
                      {iv.notes && (
                        <div>
                          <div style={{ fontSize:'0.78rem', fontWeight:700, color:'var(--text-muted)', marginBottom:3 }}>Notes</div>
                          <div className="text-sm" style={{ color:'var(--text-muted)' }}>{iv.notes}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================== OBSERVATIONS ===================== */}
      {tab === 'observations' && (
        <div>
          <div className="card" style={{ marginBottom:20 }}>
            <h2 className="section-title">Log Observation</h2>
            <form onSubmit={submitObs} noValidate>
              <div className="form-grid form-grid-2">
                <div className="form-group">
                  <label className="label" htmlFor="odate">Date *</label>
                  <input
                    id="odate"
                    type="date"
                    className="form-input"
                    value={obsForm.date}
                    onChange={e => setObsForm(f => ({ ...f, date: e.target.value }))}
                  />
                  {obsErrors.date && <div className="form-error">{obsErrors.date}</div>}
                </div>
                <div className="form-group">
                  <label className="label" htmlFor="octx">Context / Setting *</label>
                  <input
                    id="octx"
                    className="form-input"
                    placeholder="e.g. College library during exam week"
                    value={obsForm.context}
                    onChange={e => setObsForm(f => ({ ...f, context: e.target.value }))}
                  />
                  {obsErrors.context && <div className="form-error">{obsErrors.context}</div>}
                </div>
              </div>
              <div className="form-group">
                <label className="label" htmlFor="obehav">Observed Behaviour *</label>
                <textarea
                  id="obehav"
                  className="form-textarea"
                  placeholder="What did you see the user doing? Describe concretely."
                  value={obsForm.observedBehavior}
                  onChange={e => setObsForm(f => ({ ...f, observedBehavior: e.target.value }))}
                />
                {obsErrors.observedBehavior && <div className="form-error">{obsErrors.observedBehavior}</div>}
              </div>
              <div className="form-grid form-grid-2">
                <div className="form-group">
                  <label className="label" htmlFor="ofrict">Friction Point Identified</label>
                  <textarea
                    id="ofrict"
                    className="form-textarea"
                    placeholder="What difficulty or pain point did you notice?"
                    value={obsForm.frictionPoint}
                    onChange={e => setObsForm(f => ({ ...f, frictionPoint: e.target.value }))}
                    style={{ minHeight:70 }}
                  />
                </div>
                <div className="form-group">
                  <label className="label" htmlFor="oevid">Evidence Notes</label>
                  <textarea
                    id="oevid"
                    className="form-textarea"
                    placeholder="Supporting evidence (notes, photo reference ID, artefact)"
                    value={obsForm.evidenceNotes}
                    onChange={e => setObsForm(f => ({ ...f, evidenceNotes: e.target.value }))}
                    style={{ minHeight:70 }}
                  />
                </div>
              </div>
              <button type="submit" className="btn btn-primary">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                Save Observation
              </button>
            </form>
          </div>

          {observations.length === 0 ? (
            <div className="empty-state card">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <h3>No observations logged</h3>
              <p>Use the form above to record user observations from the field.</p>
            </div>
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Context</th>
                    <th>Observed Behaviour</th>
                    <th>Friction</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {observations.map(obs => (
                    <tr key={obs.id}>
                      <td style={{ whiteSpace:'nowrap' }}>{fmtDate(obs.date)}</td>
                      <td>{truncate(obs.context, 40)}</td>
                      <td>{truncate(obs.observedBehavior, 60)}</td>
                      <td>{truncate(obs.frictionPoint, 40)}</td>
                      <td>
                        <button className="btn btn-danger btn-sm" onClick={() => deleteObs(obs.id)}>Del</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ===================== JOURNEY MAP ===================== */}
      {tab === 'journey' && (
        <div>
          <div className="alert alert-info" style={{ marginBottom:16 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{flexShrink:0}}>
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="8"/><line x1="12" y1="12" x2="12" y2="16"/>
            </svg>
            <span>
              Build your journey map based on real research. Each column represents a stage in the user&apos;s experience.
              Fill in data derived from actual interviews and observations.
            </span>
          </div>

          <div className="journey-scroll">
            {journeyStages.map((s, idx) => (
              <div key={s.id || idx} className="journey-stage" style={{ minWidth:200 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
                  <input
                    className="form-input"
                    style={{ fontWeight:700, fontSize:'0.88rem', padding:'5px 8px' }}
                    value={s.stage}
                    placeholder={`Stage ${idx+1}`}
                    onChange={e => updateJourney(idx, 'stage', e.target.value)}
                  />
                  {journeyStages.length > 1 && (
                    <button
                      className="icon-btn"
                      style={{ marginLeft:6, color:'var(--danger)' }}
                      onClick={() => removeJourneyStage(idx)}
                      aria-label="Remove stage"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                      </svg>
                    </button>
                  )}
                </div>
                {[
                  { field:'action',    label:'User Action',   ph:'What does the user do?' },
                  { field:'thought',   label:'Thought',       ph:'What are they thinking?' },
                  { field:'emotion',   label:'Emotion',       ph:'😊 😐 😟 rating or word' },
                  { field:'painPoint', label:'Pain Point',    ph:'What frustrates them?' },
                ].map(row => (
                  <div key={row.field} style={{ marginBottom:8 }}>
                    <div style={{ fontSize:'0.65rem', fontWeight:700, color:'var(--text-muted)', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:3 }}>
                      {row.label}
                    </div>
                    <textarea
                      className="form-textarea"
                      style={{ minHeight:55, fontSize:'0.78rem', padding:'6px 8px' }}
                      placeholder={row.ph}
                      value={s[row.field]}
                      onChange={e => updateJourney(idx, row.field, e.target.value)}
                    />
                  </div>
                ))}
              </div>
            ))}

            {/* Add stage button */}
            <div style={{ minWidth:160, display:'flex', alignItems:'center', justifyContent:'center' }}>
              <button className="btn btn-secondary" onClick={addJourneyStage} style={{ flexDirection:'column', height:100, gap:6 }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                Add Stage
              </button>
            </div>
          </div>

          <p className="text-sm text-muted" style={{ marginTop:12 }}>
            Changes are saved automatically to your browser storage.
          </p>
        </div>
      )}
    </div>
  );
}
