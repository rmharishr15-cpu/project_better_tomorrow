# Project Better Tomorrow — Future Architecture Plan

## Stack Upgrade
- React 19 + Vite 8 (already in use)
- Zustand 5 — global state replacing scattered useLocalStorage
- React Router DOM 7 — URL-based routing
- Framer Motion 12 — page transitions + micro-animations
- TanStack Query 5 — AI API-ready async data layer
- vite-plugin-pwa — offline PWA support
- AI Service Layer — modular, pluggable provider abstraction

## Folder Structure (Feature-based)
src/
├── features/
│   ├── empathize/
│   ├── define/
│   ├── ideate/
│   ├── prototype/
│   ├── validate/
│   └── report/
├── store/          ← Zustand slices
├── services/       ← AI service abstraction
├── components/     ← Shared UI components
├── hooks/          ← Custom hooks
├── utils/
└── routes/
